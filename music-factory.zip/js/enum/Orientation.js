class Orientation {

    static UP = 0;
    static RIGHT = 1;
    static DOWN = 2;
    static LEFT = 3;

}
