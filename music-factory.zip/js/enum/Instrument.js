class Instrument {

    static PIANO = 0;
    static GUITAR = 1;
    static FLUTE = 2;
    static DRUM = 3;
    static DING = 4;

}
